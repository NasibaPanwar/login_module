<!DOCTYPE html>
<head>
    <meta charset="UTF-8" />
    <title>Import Form </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Login and Registration Form" />
    <meta name="keywords" content="html5, css3, form, switch, animation, :target, pseudo-class" />
    <link rel="stylesheet" type="text/css" href="css/demo.css" />
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <link rel="stylesheet" type="text/css" href="css/animate-custom.css" />
</head>
<?php
require_once('dbconn.php');
?>
<body>
<div class="container">
    <!-- Codrops top bar -->
    <div class="codrops-top">
        <div class="clr"></div>
    </div><!--/ Codrops top bar -->
    <header>
        <h1>Import XML</h1>
    </header>
    <section>
        <div id="container_demo" >
            <div id="wrapper">
                <div id="login" class="animate form">
                    <form method="POST" id="import_form" name="import_form" autocomplete="off" enctype="multipart/form-data">
                        <h1> Import XML</h1>
                        <p>
                            <label for="file" class="youpasswd" data-icon="e">Select XML File </label>
                            <input id="file" name="file"  type="file" placeholder="Confirm Password"/>
                        </p>
                        <p class="signin button">
                            <input type="submit" name="create" id="submit" value ="Import Xml" />

                        </p>
                    </form>
                </div>



            </div>
        </div>
    </section>
</div>

<script type="text/javascript">
    <script>
    $(document).ready(function(){
        $('#import_form').on('submit', function(event){
            event.preventDefault();

            $.ajax({
                url:"import_table.php",
                method:"POST",
                data: new FormData(this),
                contentType:false,
                cache:false,
                processData:false,
                beforeSend:function(){
                    $('#submit').attr('disabled','disabled'),
                        $('#submit').val('Importing...');
                },
                success:function(data)
                {
                    $('#message').html(data);
                    $('#import_form')[0].reset();
                    $('#submit').attr('disabled', false);
                    $('#submit').val('Import');
                }
            })

            setInterval(function(){
                $('#message').html('');
            }, 5000);

        });
    });
</script>

</script>
</body>
</html>