<?php
$data = simplexml_load_file('b.xml');
$tt =$data->product->catalog_item[0];
$product_list = $data->product;
if(!empty($product_list)) {
    $cat_log_data = array();
    foreach ($data->children() as $child) {
        $cat_log_data = $child->catalog_item;
        foreach ($child->children() as $sub_chiled) {
            $gender = $sub_chiled->attributes();
            echo $item_number = $sub_chiled->item_number;
            echo "</br>";
            $price = $sub_chiled->price;
            foreach ($sub_chiled->size as $node) {
                $g = $sub_chiled->size->attributes();
                if ($g == 'Medium') {
                    foreach ($node as $color_data) {
                        $color1 = $color_data[0];
                        $color1 = $color_data[1];

                    }
                }
                if ($g == 'Large') {
                    foreach ($node as $color_data) {
                        $color1 = $color_data[0];
                        $color1 = $color_data[1];

                    }
                }
                if ($g == 'Small') {
                    foreach ($node as $color_data) {
                        $color1 = $color_data[0];
                        $color1 = $color_data[1];

                    }
                }

            }
        }
    }
}

sleep(3);
$output = '';

if(isset($_FILES['file']['name']) &&  $_FILES['file']['name'] != '')
{
    $valid_extension = array('xml');
    $file_data = explode('.', $_FILES['file']['name']);
    $file_extension = end($file_data);
    if(in_array($file_extension, $valid_extension))
    {
        $data = simplexml_load_file($_FILES['file']['tmp_name']);
       if(!empty($data)){
           for($i = 0; $i < count($data); $i++)
           {
                       $name   = $data->employee[$i]->name;
                       $email  = $data->employee[$i]->email;
                       $address   = $data->employee[$i]->address;
                       $gender   = $data->employee[$i]->gender;
                       $designation  = $data->employee[$i]->designation;
                       $age  = $data->employee[$i]->age;
                       //==========compare with employee email===================== for unique data =================
               mysql_select_db($database_dbConn, $dbConn);
               $query_getcheckemail = "SELECT id FROM employee WHERE  email = '".mysql_real_escape_string($email)."'";
               $getcheckemail = mysql_query($query_getcheckemail, $dbConn) or die(mysql_error());
               $row_getcheckemail = mysql_fetch_assoc($getcheckemail);
               $totalRows_getcheckemail = mysql_num_rows($getcheckemail);
               if($totalRows_getcheckemail == 0){
                   $query = "INSERT INTO employee  (name,email, address, gender, designation, age)    VALUES('".mysql_real_escape_string($name)."','".mysql_real_escape_string($email)."','".mysql_real_escape_string($address)."','".mysql_real_escape_string($gender)."','".mysql_real_escape_string($designation)."','".mysql_real_escape_string($age)."',); ";
                   $getadduser = mysql_query($query, $dbConn) or die(mysql_error());
                   $last_id = mysql_insert_id();
               }
               else{
                   continue;
               }


           }
       }

        $result = $last_id;
        if(isset($result))
        {
            $output = '<div class="alert alert-success">Import Data Done</div>';
        }
    }
    else
    {
        $output = '<div class="alert alert-warning">Invalid File</div>';
    }
}
else
{
    $output = '<div class="alert alert-warning">Please Select XML File</div>';
}

echo $output;

?>

