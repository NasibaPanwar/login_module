<!DOCTYPE html>
<head>
    <meta charset="UTF-8" />
    <title>Registration Form </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Login and Registration Form" />
    <meta name="keywords" content="html5, css3, form, switch, animation, :target, pseudo-class" />
    <link rel="stylesheet" type="text/css" href="css/demo.css" />
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <link rel="stylesheet" type="text/css" href="css/animate-custom.css" />
</head>
<?php
session_start();
if(isset($_SESSION['uid']) && $_SESSION['uid'] > 0 ){

}
else{
    header("Location:login.php");
}
require_once('dbconn.php');
 $created_by =$_SESSION['uid'];
mysql_select_db($database_dbConn, $dbConn);
$query_getcheckemail = "select * from event where created_by =$created_by  OR id in ( SELECT event_id FROM assigned_event WHERE user_id  = $created_by )";
$getcheckemail = mysql_query($query_getcheckemail, $dbConn) or die(mysql_error());

$totalRows_getcheckemail = mysql_num_rows($getcheckemail);
?>
<body>
<style>
    th{font-weight: 600}
</style>
<div class="container">
    <!-- Codrops top bar -->
    <div class="codrops-top">
        <div class="clr"></div>
    </div><!--/ Codrops top bar -->
    <header>
        <h1> Event List</h1>
    </header>
    <section>
        <div id="container_demo" >
            <div id="wrapper">
                <div id="login" class="animate form">
                   <table border="1" width="100%">
                       <thead>
                           <th>Name</th>
                           <th>Start Date</th>
                           <th>End Date</th>
                           <th>Status</th>
                           <th>Action</th>

                       </thead>
                       <tbody>
                       <?php
                       while($row =mysql_fetch_array($getcheckemail)){
                       ?>                       <tr>
                           <td><?=$row['name'];?></td>
                           <td><?=$row['start_date'];?></td>
                           <td><?=$row['end_date'];?></td>
                           <td><?=ucfirst($row['status']);?></td>
                               <td><a href="share.php">Share Event</a></td>
                       </tr>
                       <?php
                       }?>
                       </tbody>
                   </table>
                </div>



            </div>
        </div>
    </section>
</div>

<script type="text/javascript">


    function validateevent() {
        var name = document.getElementById('name').value;
        if((name == "")||(name == null)){
            alert("Please enter event name");
            return false;
        }

        var start_date = document.getElementById('start_date').value;
        if((start_date == "")||(start_date == null)){
            alert("Please Select Start date");
            return false;
        }
        var end_date = document.getElementById('end_date').value;
        if((end_date == "")||(end_date == null)){
            alert("Please Select End date");
            return false;
        }

        var pass = document.getElementById('status').value;
        if((pass == "")||(pass == null)){
            alert("Please select status");
            return false;
        }

        if(start_date >end_date){
            alert("Event end date should be greater then event start date");
            return false;
        }

    }

</script>
</body>
</html>