<?php

$servername = "localhost";
$username = "root";
$password = "admin";
$database_dbConn = "test";

// Create connection
$dbConn = mysql_connect($servername, $username, $password,$database_dbConn);

// Check connection
if (!$dbConn) {
    die("Connection failed: " . mysql_error($dbConn));
}
//echo "Connected successfully";

?>
