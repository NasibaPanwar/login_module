<!DOCTYPE html>
<head>
    <meta charset="UTF-8" />
    <title>Login Form </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Login and Registration Form with HTML5 and CSS3" />
    <meta name="keywords" content="html5, css3, form, switch, animation, :target, pseudo-class" />
    <meta name="author" content="Codrops" />
    <link rel="stylesheet" type="text/css" href="css/demo.css" />
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <link rel="stylesheet" type="text/css" href="css/animate-custom.css" />
</head>
<?php
require_once('dbconn.php');
session_start();
if(isset($_SESSION['uid']) && $_SESSION['uid'] > 0 ){
    header("Location:dashboard.php");
}

if(isset($_POST['uname'])){
    $user_name = $_POST['uname'];
    $password = md5($_POST['pwd']);
    mysql_select_db($database_dbConn, $dbConn);
    $query_getadmin = "SELECT * FROM users WHERE email = '$user_name' AND password = '$password'";

    $getadmin = mysql_query($query_getadmin, $dbConn) or die(mysql_error());
    $row_getadmin = mysql_fetch_assoc($getadmin);
    $totalRows_getadmin = mysql_num_rows($getadmin);
    if($totalRows_getadmin>0){
        $_SESSION['uid'] = $row_getadmin['id'];
        $_SESSION['name'] = $row_getadmin['name'];
        $_SESSION['email'] = $row_getadmin['email'];
        header("Location:dashboard.php");
        }
      else if($totalRows_getadmin==0){ ?>
        <script> alert("Invalid user details"); </script>
    <?php }
}
?>
<body>
<div class="container">
    <!-- Codrops top bar -->
    <div class="codrops-top">
        <div class="clr"></div>
    </div><!--/ Codrops top bar -->
    <header>
        <h1>Login and Registration Form</h1>
    </header>
    <section>
        <div id="container_demo" >
                  <div id="wrapper">
                <div id="login" class="animate form">
                    <form class="admin_login" id="login_form" name="login_form" method="post" onSubmit="return validateloginForm()">
                        <h1>Log in</h1>
                        <p>
                            <label for="username" class="uname" data-icon="u" > Email </label>
                            <input id="uname" name="uname"  type="text" placeholder="Email"/>
                        </p>
                        <p>
                            <label for="password" class="youpasswd" data-icon="p"> Password </label>
                            <input id="pwd" name="pwd" type="password" placeholder="Password" />
                        </p>
                           <p class="login button">
                               <input type="submit" class="submit" id="submit" name="submit" value="Login"/>

                           </p>
                        <p class="change_link">
                            Not a register yet ?
                            <a href="register.php" class="to_register">Join us</a>
                        </p>
                    </form>
                </div>
            </div>
        </div>
    </section>
</div>
<script language = "Javascript">
    function validateloginForm() {
        var uname=document.getElementById('uname');
        if ((uname.value==null)||(uname.value=="")){
            alert("Please enter your email address");
            return false
        }
        var pwd = document.getElementById('pwd');
        if (pwd.value == "") {
            alert("Please enter your password");
            return false
        }
    }
</script>
</body>
</html>