<!DOCTYPE html>
<head>
    <meta charset="UTF-8" />
    <title>Registration Form </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Login and Registration Form" />
    <meta name="keywords" content="html5, css3, form, switch, animation, :target, pseudo-class" />
    <link rel="stylesheet" type="text/css" href="css/demo.css" />
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <link rel="stylesheet" type="text/css" href="css/animate-custom.css" />
</head>
<?php
require_once('dbconn.php');
session_start();
?>
<body>
<div class="container">
    <!-- Codrops top bar -->
    <div class="codrops-top">
        <div class="clr"></div>
    </div><!--/ Codrops top bar -->
    <header>
        <h1>User Dashboard </h1>
        <h3>Welcome ! <?=ucfirst($_SESSION['name']);?> </h3>

        <a href="logout.php" ><button type="button" class="btn btn-secondary">Logout</button></a>
        <a href="event.php" ><button type="button" class="btn btn-secondary">Create Event</button></a>
        <a href="event_list.php" ><button type="button" class="btn btn-secondary">Event List</button></a>
    </header>
    <section>
        <div id="container_demo" >
            <div id="wrapper">
            </div>
        </div>

    </section>
</div>


</body>
</html>
