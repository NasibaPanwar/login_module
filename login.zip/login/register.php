<!DOCTYPE html>
<head>
    <meta charset="UTF-8" />
    <title>Registration Form </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Login and Registration Form" />
    <meta name="keywords" content="html5, css3, form, switch, animation, :target, pseudo-class" />
      <link rel="stylesheet" type="text/css" href="css/demo.css" />
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <link rel="stylesheet" type="text/css" href="css/animate-custom.css" />
</head>
<?php
session_start();
if(isset($_SESSION['uid']) && $_SESSION['uid'] > 0 ){
    header("Location:dashboard.php");
}
require_once('dbconn.php');
$login_url =  'login.php';
$register_url = 'register.php';
if(isset($_POST['create'])){

        if(isset($_POST['email'])){
        mysql_select_db($database_dbConn, $dbConn);
        $query_getcheckemail = "SELECT * FROM users WHERE  email = '$_POST[email]'";
        $getcheckemail = mysql_query($query_getcheckemail, $dbConn) or die(mysql_error());
        $row_getcheckemail = mysql_fetch_assoc($getcheckemail);
        $totalRows_getcheckemail = mysql_num_rows($getcheckemail);
        if($totalRows_getcheckemail == 0){
            $pwd = md5($_POST['pass']);
            //create new user table
            mysql_select_db($database_dbConn, $dbConn);
            $query_getadduser = "INSERT INTO `users` (`name`,  `email`, `password`) VALUES ('$_POST[name]', '$_POST[email]', '$pwd')";
            $getadduser = mysql_query($query_getadduser, $dbConn) or die(mysql_error());
            $last_id = mysql_insert_id();
            $errmsg = "Thank you for registering.";
            header('Location: '.$login_url);

        } else { //email already existed

            $errmsg = "* Email address already existed,<br> please try again enter another email address";
           // header('Location: '.$register_url);
                   }

    }

}?>
<body>
<div class="container">
    <!-- Codrops top bar -->
    <div class="codrops-top">
        <div class="clr"></div>
    </div><!--/ Codrops top bar -->
    <header>
        <h1>Login and Registration Form</h1>
    </header>
    <section>
        <div id="container_demo" >
            <div id="wrapper">
                <div id="login" class="animate form">
                    <form method="POST" id="register_form" name="register_form" autocomplete="off" onSubmit="return validateregister()">
                        <h1> Sign up </h1>

                        <?php
                        if(isset($errmsg) && $errmsg != ""){?>
                            <p class="ptag" style="font-weight:bold;color:red;font-size:15px;"><?php echo $errmsg; ?></p>
                        <?php }else{?>
                            <div class="clearfix">&nbsp;</div>
                        <?php }?>
                        <p>
                            <label for="usernamesignup" class="uname" data-icon="u"> Name</label>
                            <input id="name" name="name" type="text" placeholder="Name" />
                        </p>
                        <p>
                            <label for="emailsignup" class="youmail" data-icon="e" > Email</label>
                            <input id="email" name="email" type="email" placeholder="Email"/>
                        </p>
                        <p>
                            <label for="passwordsignup" class="youpasswd" data-icon="p">Password </label>
                            <input id="password" name="password" type="password" placeholder="Password"/>
                        </p>
                        <p>
                            <label for="passwordsignup_confirm" class="youpasswd" data-icon="p">Confirm Password </label>
                            <input id="c_password" name="c_password"  type="password" placeholder="Confirm Password"/>
                        </p>
                        <p class="signin button">
                            <input type="submit" name="create" id="create" value="Sign up" />

                        </p>
                        <p class="change_link">
                            Already a register ?
                            <a href="login.php" class="to_register"> Go and log in </a>
                        </p>
                    </form>
                </div>



            </div>
        </div>
    </section>
</div>

<script type="text/javascript">


    function validateregister() {
        var name = document.getElementById('name').value;
        if((name == "")||(name == null)){
            alert("Please enter your name");
            return false;
        }

        var email = document.getElementById('email').value;
        if((email == "")||(email == null)){
            alert("Please enter email address");
            return false;
        }

        if (echeck(email)==false){
            return false;
        }

        var pass = document.getElementById('password').value;
        if((pass == "")||(pass == null)){
            alert("Please enter password");
            return false;
        }

        var cpass = document.getElementById('c_password').value;
        if((cpass == "")||(cpass == null)){
            alert("Please enter confirm password");
            return false;
        }

        if(pass!=cpass){
            alert("Please enter confirm password match with password");
            return false;
        }

    }

    function echeck(str) {
        var at="@"
        var dot="."
        var lat=str.indexOf(at)
        var lstr=str.length
        var ldot=str.indexOf(dot)
        if (str.indexOf(at)==-1){
            alert("Incorrect email address");
            return false
        }

        if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
            alert("Incorrect email address");
            return false
        }

        if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
            alert("Incorrect email address");
            return false
        }

        if (str.indexOf(at,(lat+1))!=-1){
            alert("Incorrect email address");
            return false
        }

        if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
            alert("Incorrect email address");
            return false
        }

        if (str.indexOf(dot,(lat+2))==-1){
            alert("Incorrect email address");
            return false
        }

        if (str.indexOf(" ")!=-1){
            alert("Incorrect email address");
            return false
        }
    }
    </script>
</body>
</html>