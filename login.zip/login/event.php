<!DOCTYPE html>
<head>
    <meta charset="UTF-8" />
    <title>Registration Form </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Login and Registration Form" />
    <meta name="keywords" content="html5, css3, form, switch, animation, :target, pseudo-class" />
    <link rel="stylesheet" type="text/css" href="css/demo.css" />
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <link rel="stylesheet" type="text/css" href="css/animate-custom.css" />
</head>
<?php
session_start();
if(isset($_SESSION['uid']) && $_SESSION['uid'] > 0 ){

}
else{
    header("Location:login.php");
}
require_once('dbconn.php');
$login_url =  'event_list.php';
if(isset($_POST['create'])){

            $created_by =$_SESSION['uid'];

            mysql_select_db($database_dbConn, $dbConn);
            $query_getadduser = "INSERT INTO `event` (`name`,  `start_date`, `end_date`,`status`,`created_by`) VALUES ('$_POST[name]', '$_POST[start_date]','$_POST[end_date]','$_POST[status]', '$created_by')";
            $getadduser = mysql_query($query_getadduser, $dbConn) or die(mysql_error());
            $last_id = mysql_insert_id();
            $errmsg = "Event Created Successfully";
            header('Location: '.$login_url);
}?>
<body>
<div class="container">
    <!-- Codrops top bar -->
    <div class="codrops-top">
        <div class="clr"></div>
    </div><!--/ Codrops top bar -->
    <header>
        <h1>Create Event</h1>
    </header>
    <section>
        <div id="container_demo" >
            <div id="wrapper">
                <div id="login" class="animate form">
                    <form method="POST" id="register_form" name="register_form" autocomplete="off" onSubmit="return validateevent()">
                        <h1> Create Event </h1>

                        <p>
                            <label for="usernamesignup" class="uname" data-icon="u"> Name</label>
                            <input id="name" name="name" type="text" placeholder="Event Name" />
                        </p>
                        <p>
                            <label for="usernamesignup" class="uname" data-icon="e"> Start Date</label>

                            <input type="date" class="form-control" name="start_date" id="start_date">
                        </p> <p>
                            <label for="usernamesignup" class="uname" data-icon="e"> End Date</label>
                            <input type="date" class="form-control" id ="end_date" name="end_date">

                        </p>
                        <p>
                            <label for="usernamesignup" class="uname" data-icon="e"> Status</label>
                            <select name="status" id="status" >
                                <option value="">Event Status</option>
                                <option value="active">Active</option>
                                <option value="hold">Hold</option>
                                <option value="inactive">Inactive</option>
                                <option value="closed">Closed</option>
                            </select>
                        </p>

                        <p class="signin button">
                            <input type="submit" name="create" id="create" value="Create Event" />

                        </p>
                    </form>
                </div>



            </div>
        </div>
    </section>
</div>

<script type="text/javascript">


    function validateevent() {
        var name = document.getElementById('name').value;
        if((name == "")||(name == null)){
            alert("Please enter event name");
            return false;
        }

        var start_date = document.getElementById('start_date').value;
        if((start_date == "")||(start_date == null)){
            alert("Please Select Start date");
            return false;
        }
         var end_date = document.getElementById('end_date').value;
        if((end_date == "")||(end_date == null)){
            alert("Please Select End date");
            return false;
        }

        var pass = document.getElementById('status').value;
        if((pass == "")||(pass == null)){
            alert("Please select status");
            return false;
        }

        if(start_date >end_date){
            alert("Event end date should be greater then event start date");
            return false;
        }

    }

</script>
</body>
</html>