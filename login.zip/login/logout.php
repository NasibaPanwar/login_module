<?php require_once('dbconn.php');
session_start();
	unset($_SESSION['uid']);
	unset($_SESSION['name']);
	unset($_SESSION['email']);
	session_destroy();
header("Location:login.php");
?>
