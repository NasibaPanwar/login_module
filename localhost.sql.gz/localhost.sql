-- Adminer 4.7.1 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

CREATE DATABASE `test` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `test`;

DROP TABLE IF EXISTS `assigned_event`;
CREATE TABLE `assigned_event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `shared_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `event_id` (`event_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `assigned_event_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `event` (`id`),
  CONSTRAINT `assigned_event_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `assigned_event` (`id`, `event_id`, `user_id`, `shared_by`) VALUES
(1,	3,	2,	1);

DROP TABLE IF EXISTS `employee`;
CREATE TABLE `employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(250) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `gender` varchar(10) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `age` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `employee` (`id`, `email`, `name`, `address`, `gender`, `designation`, `age`) VALUES
(1,	'',	'William T. Strauss',	'2210 Roosevelt Road Pittsburg, KS 66762',	'Male',	'Transmission technician',	42),
(2,	'',	'David N. Bateman',	'3729 Sycamore Fork Road Miami, FL 33176',	'Male',	'Vegetable cook',	44),
(3,	'',	'Gail P. Robinson',	'991 Ashmor Drive Crookston, MN 56716',	'Female',	'Personnel administrator',	51),
(4,	'',	'James M. Cardin',	'120 Kuhl Avenue Atlanta, GA 30303',	'Male',	'Switchboard operator',	21),
(5,	'',	'Jason K. Peterson',	'1029 Lords Way Memphis, TN 38118',	'Male',	'Pediatrician',	43),
(6,	'',	'Penni G. Vazquez',	'1545 Whiteman Street Camden, NJ 08102',	'Female',	'Tractor driver',	33),
(7,	'',	'David A. Davis',	'617 Spirit Drive Port Orange, FL 32019',	'Male',	'Oncology nurse',	34),
(8,	'',	'Kimberly J. Hemingway',	'4874 Lynn Street Woburn, MA 01801',	'Female',	'Leasing manager',	32),
(9,	'',	'Corine C. Conner',	'1595 Meadowview Drive Fredericksburg, VA 22408',	'Female',	'Model',	22),
(10,	'',	'Ben A. Champagne',	'3736 Hartland Avenue Appleton, WI 54913',	'Male',	'Commentator',	21),
(11,	'',	'Mary J. Smith',	'727 Alexander Drive Arlington, TX 76011',	'Female',	'Safety inspector',	35),
(12,	'',	'Buford R. Quinn',	'2717 McDowell Street Nashville, TN 37210',	'Male',	'Log debarker',	23),
(13,	'',	'Lawrence P. Walters',	'4488 Stratford Court Rocky Mount, NC 27801',	'Male',	'Mechanical drafter',	26),
(14,	'',	'Armando T. Trainor',	'1272 Small Street New York, NY 10016',	'Male',	'Clinical laboratory technologist',	21),
(15,	'',	'Cathy H. Maldonado',	'287 Lakeland Terrace Southfield, MI 48075',	'Female',	'Dipper',	31),
(16,	'',	'Elizabeth M. Manning',	'2398 Wines Lane Houston, TX 77032',	'Female',	'Hearing therapist',	34),
(17,	'',	'Jon B. Parker',	'4317 Stuart Street Saxonsburg, PA 16056',	'Male',	'Watch repairer',	28),
(18,	'',	'Lindsey C. Myers',	'3529 Confederate Drive Earlville, NY 13332',	'Male',	'Cleaner',	42),
(19,	'',	'Stephen T. Armijo',	'2488 Confederate Drive Syracuse, NY 13202',	'Male',	'Legal secretary',	46),
(20,	'',	'Estelle A. Sawyer',	'2613 Creekside Lane Santa Barbara, CA 93178',	'Female',	'Dispatcher',	39);

DROP TABLE IF EXISTS `event`;
CREATE TABLE `event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `event` (`id`, `name`, `start_date`, `end_date`, `status`, `created_by`) VALUES
(1,	'IMAP',	'2020-06-27',	'2020-06-28',	'hold',	2),
(2,	'test',	'2020-06-27',	'2020-06-28',	'hold',	2),
(3,	'java',	'2020-06-27',	'2020-06-28',	'active',	1);

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES
(1,	'nasiba',	'nasiba@gmail.com',	'd41d8cd98f00b204e9800998ecf8427e'),
(2,	'varsha',	'varsha@gmail.com',	'e10adc3949ba59abbe56e057f20f883e'),
(3,	'nasiba',	'nasiba@gmail.cm',	'd41d8cd98f00b204e9800998ecf8427e');

-- 2020-06-27 17:29:48
